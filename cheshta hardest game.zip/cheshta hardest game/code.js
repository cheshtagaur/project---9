var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

playSound("assets/default.mp3", true);

var wall1 = createSprite(250, 130, 300, 5);


var wall2 = createSprite(150, 270, 300, 5);

var you = createSprite(20, 335, 15, 15);
you.shapeColor = "green";


var ball1 = createSprite(80, 335, 10, 10);
var ball2 = createSprite(120, 335, 10, 10);
var ball3 = createSprite(160, 335, 10, 10);
var ball4 = createSprite(200, 335, 10, 10);
var ball5 = createSprite(240, 335, 10, 10);
var ball6 = createSprite(280, 335, 10, 10);
ball1.shapeColor = "red";
ball2.shapeColor = "red";
ball3.shapeColor = "red";
ball4.shapeColor = "red";
ball5.shapeColor = "red";
ball6.shapeColor = "red";


var sDoor1 = createSprite(360, 270, 50, 8);
var sDoor2 = createSprite(40, 130, 50, 8);
sDoor1.shapeColor = "red";
sDoor2.shapeColor = "red";


var line1 = createSprite(125, 200, 50, 7);
var line2 = createSprite(200, 200, 50, 7);
var line3 = createSprite(275, 200, 50, 7);
line1.shapeColor = "red";
line2.shapeColor = "red";
line3.shapeColor = "red";


var ball7 = createSprite(200, 100, 10, 10);
var ball8 = createSprite(250, 100, 10, 10);
var ball9 = createSprite(200, 50, 10, 10);
var ball10 = createSprite(250, 50, 10, 10);
ball7.shapeColor = "red";
ball8.shapeColor = "red";
ball9.shapeColor = "red";
ball10.shapeColor = "red";


var objective = createSprite(360, 75, 20, 20);
objective.shapeColor = "yellow";


var score = 0;


var gameState = "play";







//playSound("assets/category_music/clear_evidence_loop1.mp3", true);

velocity();

function draw() {
  background("lightblue");
  bounce();
  if(keyDown("left")){
   you.x = you.x-3;
   gameState = "play";
  }
  if(keyDown("right")){
    you.x = you.x+3;
    gameState = "play";
  }
  if(keyDown("up")){
    you.y = you.y-3;
    gameState = "play";
  }
  if(keyDown("down")){
    you.y = you.y+3;
    gameState = "play";
  }
  
  text("DEATHS: "+score, 10, 10);
  
  
  if(you.collide(ball1)||you.collide(ball2)||you.collide(ball3)||you.collide(ball4)
     ||you.collide(ball5)||you.collide(ball6)||you.collide(ball7)||
     you.collide(ball8)||you.collide(ball9)||you.collide(ball10)||
     you.collide(sDoor1)||you.collide(sDoor2)||you.collide(line1)||
     you.collide(line2)||you.collide(line3)){
    reset();
    score = score+1;
  }
  
  if(you.collide(objective)){
    gameState = "over";
    text("YOU WIN!",200, 200);
    you.velocityX = 0.0000001;
    you.velocityY = 0.0000001;
    score = 0;
    text("press R to restart", 200, 220);
  }
  
  if(keyDown("R")&&gameState === "over"){
    reset();
  }
  
  

  
  drawSprites();
  
}
















function reset(){
  you.x = 20;
  you.y = 335;
  you.velocityX = 0;
  you.velocityY = 0;
}


function velocity(){
  
  
  ball1.velocityY = 10;
  ball2.velocityY = -10;
  ball3.velocityY = 10;
  ball4.velocityY = -10;
  ball5.velocityY = 10;
  ball6.velocityY = -10;
  ball7.velocityY = 10;
  ball8.velocityX = -10;
  ball9.velocityX = 10;
  ball10.velocityY = -10;
  line1.velocityY = 5;
  line2.velocityY = -5;
  line3.velocityY = 5;
  sDoor1.velocityX = 3;
  sDoor2.velocityX = -3;
}



function bounce(){
  createEdgeSprites();
  ball1.bounceOff(edges);
  ball2.bounceOff(edges);
  ball3.bounceOff(edges);
  ball4.bounceOff(edges);
  ball5.bounceOff(edges);
  ball6.bounceOff(edges);
  ball1.bounceOff(edges);
  ball2.bounceOff(edges);
  ball3.bounceOff(edges);
  ball4.bounceOff(edges);
  ball5.bounceOff(edges);
  ball6.bounceOff(edges);
  ball7.bounceOff(edges);
  ball8.bounceOff(edges);
  ball9.bounceOff(edges);
  ball10.bounceOff(edges);
  sDoor1.bounceOff(edges);
  sDoor2.bounceOff(edges);
  you.bounceOff(edges);
  
  
  ball1.bounceOff(wall2);
  ball2.bounceOff(wall2);
  ball3.bounceOff(wall2);
  ball4.bounceOff(wall2);
  ball5.bounceOff(wall2);
  ball6.bounceOff(wall2);
  
  sDoor1.bounceOff(wall2);
  sDoor2.bounceOff(wall1);
  
  line1.bounceOff(wall1);
  line1.bounceOff(wall2);
  line2.bounceOff(wall1);
  line2.bounceOff(wall2);
  line3.bounceOff(wall1);
  line3.bounceOff(wall2);
  line1.bounceOff(edges);
  line2.bounceOff(edges);
  line3.bounceOff(edges);
  
  ball7.bounceOff(wall1);
  ball8.bounceOff(wall1);
  ball9.bounceOff(wall1);
  ball10.bounceOff(wall1);
  
  you.bounceOff(wall1);
  you.bounceOff(wall2);
}









// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
